# Nordent Clinic — Publication Kit

All presentation copy is in English. Design credit follows the supplied preview: UX.RONA.

## Instagram

- Carousel: 8 JPG files, 1080 × 1350 (4:5), numbered in upload order.
- Stories: 3 JPG files, 1080 × 1920 (9:16).
- Reel: 20-second portrait presentation MP4, 1080 × 1920, 30 fps, H.264, no audio.
- Cover: reel-cover.jpg. Use CAPTION.txt, REEL-CAPTION.txt and ALT-TEXT.txt.
- Upload carousel images in numerical order and keep the 4:5 crop consistent. Add your portfolio link to your profile or Story link sticker after it is live.

## Dribbble

- Four 1600 × 1200 JPG canvases. Publish 01-desktop as the lead shot; 02 and 03 are alternatives or follow-up posts.
- interaction-preview.mp4 shows real website interactions on a 1600 × 1200 presentation canvas, H.264 / 30 fps.
- Use POSTS.txt for separate shot titles, descriptions and tags.

## Behance

- The supplied opening preview and cover are preserved as originals.
- cover-808x632.jpg fits the supplied blue artwork within Behance's cover proportions without cropping it.
- 14 numbered JPG modules are 1400 px wide. Upload in UPLOAD-ORDER.txt order.
- PROJECT-TEXT.txt contains the English case narrative, title, tags and credits.

## GitHub

- github/repository contains a clean repository upload without node_modules, .git, local work files, credentials or the original .fig.
- Upload the contents of that folder to ronikawx1888/nordent-clinic. Replace the initial placeholder README with the supplied README.
- The project includes source, image/font assets, previews, documentation and a build workflow.
- Repository Settings → General → Social preview: use github/social-preview-1280x640.jpg.
- The repository is not the deployed website. A live site URL is intentionally not claimed.

## Export decisions and sources

These are delivery presets, not claims about maximum platform limits. Instagram 4:5 was selected for broad publishing compatibility; 9:16 is used for vertical material. Meta's help page could not be fetched during preparation, so maximum limits have not been asserted.

- Behance project images: https://help.behance.net/hc/en-us/articles/204484614-Guide-Formatting-Images-For-Display-On-Behance
- Behance covers: https://help.behance.net/hc/en-us/articles/360033998134-Guide-Cover-Images
- Dribbble's official 1600 × 1200 presentation reference: https://dribbble.com/shots/5010706-That-s-a-lot-of-pixels
- Instagram image help: https://help.instagram.com/1631821640426723

## Status

Assets are prepared for upload. Social accounts have not been supplied or connected, so no Instagram, Dribbble or Behance post has been published. GitHub publishing status is recorded separately in github/STATUS.txt.
